
suppressPackageStartupMessages({
  library(dplyr)
  library(stringr)
  library(purrr)
  library(pbmcapply)
  library(tidyr)
  library(ggplot2)
  library(data.table)
  library(dtplyr)
  library(arrow)
  library(microbenchmark)
  library(profvis)
})

source("/home/fabian/RProjects/mas/R/03-analysis.R")

mat <- matrix(
  data = c(
    c(1, 2, 3),
    c(2, 3, 4),
    c(1, 2, 3.5),
    c(1, 2, 2.5)
  ),ncol = 3, byrow = TRUE)

group <- c(2, 2, 1, 1)

nn2_cpp2(data = mat, query = mat, group = group, k = 4, k_internal = 4)

quotes_line <- arrow::read_feather("/home/fabian/RProjects/mas/tmp/quotes_line.feather")
data_wide_0 <- arrow::read_feather("/home/fabian/RProjects/mas/tmp/data_wide_0.feather")

data_wide_0$Date <- quotes_line$Date

non_na_rows_bool <- rowSums(is.na(data_wide_0)) == 0

data_wide_0 <- data_wide_0[non_na_rows_bool, ]
orig_order <- order(desc(data_wide_0$Date))

data_wide_0 <- data_wide_0 %>%
  select(-Ticker) %>%
  arrange(desc(Date))

counts <- data_wide_0 %>% select(Date) %>% group_by(Date) %>% summarise(cnt = n()) %>% ungroup() %>% mutate(cum_sum = cumsum(cnt))

n_chunks <- 100
breaks <- head(nrow(data_wide_0) / (n_chunks + 1) * seq_len(n_chunks + 1), -1)

split_dates <- map(breaks, ~counts$Date[[min(which(counts$cum_sum>.))]])
dates <- data_wide_0$Date

nn <- function(i, split_dates = split_dates, data = as.matrix(select(data_wide_0, !c(ends_with("_0"), any_of("Date")))), dates = data_wide_0$Date){
  split_date = split_dates[[i]]
  curr_data <- data[dates <= split_date, ]
  curr_dates <- dates[dates <= split_date]
  curr_query <- data[dates > split_date & dates <= split_dates[[i+1]], ]
  nn2_cpp2(data = curr_data, query = curr_query, group = as.integer(curr_dates), k = 50, k_internal = 1.2*50)
}

samples <- sample(n_chunks)
out <- pbmcapply::pbmclapply(
  X = samples[seq_len(1:3)],
  FUN = nn,
  split_dates = split_dates,
  data = as.matrix(select(data_wide_0, !c(ends_with("_0"), any_of("Date")))),
  dates = data_wide_0$Date,
  mc.cores = 3
)
