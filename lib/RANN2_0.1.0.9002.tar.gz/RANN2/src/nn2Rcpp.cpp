
#include <Rcpp.h>
#include <ANN/ANN.h>     // ANN library header

// #include <omp.h>
// // [[Rcpp::plugins(openmp)]]

using namespace Rcpp;

ANNkd_tree* init_tree(NumericMatrix data, ANNpointArray data_pts, int nd, int d) {
  int offset = data.nrow() - nd;

  // now construct the points
  for(int i = 0; i < nd; i++)
  {
    for(int j = 0; j < d; j++)
    {
      data_pts[i][j]=data(i + offset,j);
    }
  }
  return new ANNkd_tree(data_pts, nd, d);
}


// [[Rcpp::export]]
List nn2_cpp2(NumericMatrix data, NumericMatrix query, IntegerVector group, const int k, const int k_internal, const double eps=0.0) {

  const int d=data.ncol();
  int nd=data.nrow();
  const int nq=query.nrow();
  ANNidxArray nn_idx = new ANNidx[k_internal];		// Allocate near neigh indices
  ANNdistArray dists = new ANNdist[k_internal];		// Allocate near neighbor dists
  int newly_created_tree;

  // return values here
  NumericMatrix rdists(nq, k);
  IntegerMatrix ridx(nq, k);

  // ANNkd_tree	*the_tree;	// Search structure
  ANNkd_tree	*the_tree;	// Search structure
  ANNpointArray data_pts;

  data_pts = annAllocPts(nd,d);		// Allocate data points
  the_tree = init_tree(data, data_pts, nd, d);

  newly_created_tree = 0;

  //now iterate over query points
  ANNpoint pq = annAllocPt(d);
  // #pragma omp parallel for
  for(int i = 0; i < nq; i++)	// Run all query points against tree
  {

    if (i % 1000 == 0) {
      Rprintf("Counter: %i\n", i);
    }

    // read coords of current query point
    for(int j = 0; j < d; j++)
    {
      pq[j]=query(i,j);
    }

    int out_j = 0;
    int n_neighbors = std::min(nd, k_internal);
    the_tree->annkSearch(	// search
        pq,	// query point
        n_neighbors,		// number of near neighbors
        nn_idx,		// nearest neighbors (returned)
        dists,		// distance (returned)
        eps);	// error bound

    int offset = data.nrow() - nd;
    int j;
    for (j = 0; j < n_neighbors; j++) {

      if (group[nn_idx[j] + offset] < group[i]) {
        rdists(i, out_j) = sqrt(dists[j]);	// unsquare distance
        ridx(i, out_j) = nn_idx[j] + offset + 1;	// put indices in returned array (nb +1 for R)
        out_j++;
      }
      if (out_j == k) {
        break;
      }
    }

    // create new tree
    if (out_j < k and newly_created_tree < i) {

      int next_group_offest = 1;
      while(group.length() > (i + next_group_offest) and group[i] == group[i + next_group_offest]) {
        next_group_offest++;
      }
      nd = data.nrow() - i - next_group_offest;

      Rprintf("Next Group Offest: %i\n", next_group_offest);

      if (nd > 0) {
        Rprintf("Build new tree: %i\n", i);
        annDeallocPts(data_pts);
        data_pts = annAllocPts(nd,d);		// Allocate data points
        delete the_tree;
        the_tree = init_tree(data, data_pts, nd, d);
      }

      newly_created_tree = i;
      i--;
    } else {

      // fill up with NA
      for (int na_fill = out_j; na_fill<k; na_fill++) {
        rdists(i, na_fill) = NA_REAL;
        ridx(i, na_fill) = NA_INTEGER;
      }
    }
  }

  annDeallocPt(pq);
  annDeallocPts(data_pts);

  delete the_tree;
  delete [] nn_idx;
  delete [] dists;

  List z = List::create(Rcpp::Named("nn.idx")=ridx, Rcpp::Named("nn.dists")=rdists);
  return z ;
}
