# RANN2 (development version)

* Updates to match RANN v2.6.1
* Now exports and documents WANN class
* Added a `NEWS.md` file to track changes to the package.
