.onUnload <- function (libpath) {
  library.dynam.unload("RANN2", libpath)
  
  invisible()
}
