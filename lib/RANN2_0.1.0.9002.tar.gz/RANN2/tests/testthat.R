library(testthat)
library(RANN2)

test_check("RANN2")
